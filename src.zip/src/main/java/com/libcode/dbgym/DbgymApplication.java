package com.libcode.dbgym;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbgymApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbgymApplication.class, args);
	}

}
