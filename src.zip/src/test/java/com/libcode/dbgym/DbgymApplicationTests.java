package com.libcode.dbgym;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbgymApplicationTests {

	@Test
	void contextLoads() {
	}

}
